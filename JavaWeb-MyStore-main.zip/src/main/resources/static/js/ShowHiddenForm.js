// JavaScript 函数，用于显示弹窗 
function openForm() {
document.getElementById("Hidden").style.display = "block"; 
} 
// JavaScript 函数，用于关闭弹窗 
function closeForm() {
document.getElementById("Hidden").style.display = "none";
}

